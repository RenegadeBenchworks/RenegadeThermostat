
# Recommended Repository Structure

```
esp32-touch-ui/
│
├── README.md
├── LICENSE
├── platformio.ini
│
├── src/
│   ├── main.cpp
│   ├── UIManager.h
│   ├── UIPage.h
│   ├── UIButton.h
│   ├── WeatherIconRenderer.h
│   └── ThermostatHomePage.h
│
├── icons/
│   ├── gear_32.png
│   ├── plus_32.png
│   └── minus_32.png
│
├── tools/
│   └── export_rgb565.py
│
├── docs/
│   ├── architecture.md
│   └── layout-guide.md
│
└── examples/
    └── thermostat_demo/
        └── main.cpp
```
