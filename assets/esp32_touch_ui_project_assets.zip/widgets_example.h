
#pragma once

struct UIWidget {

    int x;
    int y;
    int w;
    int h;

    virtual void draw() = 0;
    virtual void onTouch(int tx,int ty) {}
};

class UIButton : public UIWidget {

public:

    const char* label;

    void (*callback)();

    void draw() override {
        // draw button rectangle + label
    }

    void onTouch(int tx,int ty) override {
        if(callback) callback();
    }
};
