
# PNG -> RGB565 exporter
# Usage: python export_rgb565.py icon.png

from PIL import Image
import sys

def rgb_to_565(r,g,b):
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)

img = Image.open(sys.argv[1]).convert("RGB")
w,h = img.size

pixels = list(img.getdata())

print(f"const uint16_t icon[{w*h}] PROGMEM = {{")

for i,(r,g,b) in enumerate(pixels):
    val = rgb_to_565(r,g,b)
    end = ","
    if i == len(pixels)-1:
        end=""
    print(f"0x{val:04X}{end}", end="")
    if i % w == w-1:
        print()

print("};")
