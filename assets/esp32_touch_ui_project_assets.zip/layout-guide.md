
# Layout Grid Guide

For a 480x320 display.

Suggested grid:

```
Columns: 12
Rows: 8
```

Example zones:

```
+------------------------------------------------+
| Header (row 0)                                 |
+------------------------------------------------+
|                                                |
|              Main Temperature                  |
|                                                |
|   [-]     Target Temp      [+]                 |
|                                                |
+------------------------------------------------+
| Weather / Status row                           |
+------------------------------------------------+
```

Example layout helper:

```cpp
struct Grid {
    int cols = 12;
    int rows = 8;
    int width = 480;
    int height = 320;

    int col(int c) { return (width / cols) * c; }
    int row(int r) { return (height / rows) * r; }
};
```
