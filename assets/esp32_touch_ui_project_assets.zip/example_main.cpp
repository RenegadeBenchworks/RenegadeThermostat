
#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7796S_kbv.h>

Adafruit_ST7796S_kbv tft;

int currentTemp = 72;
int targetTemp = 70;

void drawUI(){

    tft.fillScreen(ST77XX_BLACK);

    tft.setTextSize(5);
    tft.setCursor(180,120);
    tft.print(currentTemp);

    tft.setTextSize(2);
    tft.setCursor(120,200);
    tft.print("-");

    tft.setCursor(320,200);
    tft.print("+");
}

void setup(){

    tft.begin();
    tft.setRotation(1);

    drawUI();
}

void loop(){
}
